#ifndef __OJ_H__
#define __OJ_H__

int GetResult(const char *input, char *output);

#endif
