#ifndef __OJ_H__
#define __OJ_H__

unsigned int Continumax(char** pOutputstr,  char* intputstr);

#endif
