#ifndef __OJ_H__
#define __OJ_H__

int CalcArmstrongNumber(int n);

#endif
