#ifndef __OJ_H__
#define __OJ_H__

void GetResult(int InputNum, double *NumResult);

double fact(int k);

#endif
