#ifndef __OJ_H__
#define __OJ_H__

#include <vector>
#include <algorithm>
using namespace std;

unsigned int GetBitsValue(unsigned int input, unsigned int startbit, unsigned int bitlen);


#endif
