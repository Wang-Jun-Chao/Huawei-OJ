#ifndef __OJ_H__
#define __OJ_H__


void OutputMaxAndMin(int * pInputInteger, int InputNum, int * pMaxValue, int * pMaxNum, int * pMinValue, int * pMinNum);


#endif
