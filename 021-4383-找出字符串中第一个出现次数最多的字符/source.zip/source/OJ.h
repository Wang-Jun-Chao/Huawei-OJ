#ifndef __OJ_H__
#define __OJ_H__

bool FindChar(char* pInputString, char* pChar);


#endif
