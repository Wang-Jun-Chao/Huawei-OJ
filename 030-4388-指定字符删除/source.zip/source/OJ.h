#ifndef __OJ_H__
#define __OJ_H__


int removechars(char *in, char c, char *out);

#endif
