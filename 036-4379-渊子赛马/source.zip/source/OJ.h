#ifndef __OJ_H__
#define __OJ_H__





char * IsYuanziWin(unsigned int num, unsigned int * speed_yz, unsigned int * speed_op);


#endif
