#ifndef __OJ_H__
#define __OJ_H__

void CalcNN(int n, char *pOut);

#endif
