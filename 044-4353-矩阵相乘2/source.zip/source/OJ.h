#ifndef __OJ_H__
#define __OJ_H__


int matrix(int **MatrixA, int **MatrixB, int **MatrixC, int N);

#endif
