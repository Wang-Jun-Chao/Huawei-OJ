#ifndef __OJ_H__
#define __OJ_H__

bool Game24Points(int a, int b, int c, int d);

#endif
